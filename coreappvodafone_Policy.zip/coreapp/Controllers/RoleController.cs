﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using coreapp.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace coreapp.Controllers
{
    public class RoleController : Controller
    {

        ApplicationDbContext ctx;
        RoleManager<IdentityRole> roleManager;
        public RoleController(ApplicationDbContext ctx, 
            RoleManager<IdentityRole> roleManager)
        {
            this.ctx = ctx;
            this.roleManager = roleManager;
        }
        public IActionResult Index()
        {
            var roles = roleManager.Roles.ToList();
            return View(roles);
        }

        public IActionResult Create()
        {
            return View(new IdentityRole());
        }

        [HttpPost]
        public  IActionResult Create(IdentityRole role)
        {
            var r =  roleManager.CreateAsync(role).Result;
            return RedirectToAction("Index");
        }
    }
}