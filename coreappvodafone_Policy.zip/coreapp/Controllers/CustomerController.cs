﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using coreapp.Models;
using coreapp.Services;
using Microsoft.AspNetCore.Authorization;

namespace coreapp.Controllers
{
   
    public class CustomerController : Controller
    {
        IService<Customers, int> custService;
        public CustomerController(IService<Customers, int> custService)
        {
            this.custService = custService;
        }
        [Authorize(Policy ="ReadPolicy")]
        public IActionResult Index()
        {
            var customers = custService.GetAsync().Result;
            return View(customers);
        }

        [Authorize(Policy = "WritePolicy")]
        public IActionResult Create()
        {
            var customer = new Customers();
            return View(customer);
        }

        [HttpPost]
        public IActionResult Create(Customers customer)
        {
            //try
            //{
                 if (ModelState.IsValid)
                {
                    if (customer.City.Length >= 10) throw new Exception("City Name can not be such huge");
                       customer = custService.Create(customer).Result;
                    return RedirectToAction("Index");
                }
                return View(customer);
           // }
            //catch (Exception ex)
            //{
            //    return View("Error", 
            //        new ErrorViewModel() {
            //             ControllerName = RouteData.Values["controller"].ToString(),
            //             ActionName = RouteData.Values["action"].ToString(),
            //             ErrorMessage = ex.Message
            //        });
            //}
        }

        public IActionResult Edit(int id)
        {
            var customer = custService.GetAsync(id).Result;
            return View(customer);
        }

        [HttpPost]
        public IActionResult Edit(int id, Customers customer)
        {
            if (ModelState.IsValid)
            {
                customer = custService.Update(id,customer).Result;
                return RedirectToAction("Index");
            }
            return View(customer);
        }

        public IActionResult Delete(int id)
        {
            var res = custService.Delete(id).Result;
            if (res)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
    }
}