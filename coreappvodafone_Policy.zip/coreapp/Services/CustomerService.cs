﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using coreapp.Models;
using Microsoft.EntityFrameworkCore;

namespace coreapp.Services
{
    public class CustomerService : IService<Customers, int>
    {
        AppDbVodafoneContext ctx; 
        public CustomerService(AppDbVodafoneContext ctx)
        {
            this.ctx = ctx;
        }

        public  async Task<Customers> Create(Customers entity)
        {
            var res = await ctx.Customers.AddAsync(entity);
            await ctx.SaveChangesAsync();
            return res.Entity;
        }

        public  async Task<bool> Delete(int id)
        {
            var res = await ctx.Customers.FindAsync(id);
            if (res != null)
            {
                ctx.Customers.Remove(res);
                await ctx.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<IEnumerable<Customers>> GetAsync()
        {
            return await ctx.Customers.ToListAsync();
        }

        public async Task<Customers> GetAsync(int id)
        {
            return await ctx.Customers.FindAsync(id);
        }

        public async Task<Customers> Update(int id, Customers entity)
        {
            var res = await ctx.Customers.FindAsync(id);
            if (res != null)
            {
                //ctx.Update<Customers>(entity).State 
                //    = EntityState.Modified;
                res.CustomerId = entity.CustomerId;
                res.CustomerName = entity.CustomerName;
                res.EmailAddress = entity.EmailAddress;
                res.Address = entity.Address;
                res.City = entity.City;
                res.State = entity.State;
                await ctx.SaveChangesAsync();
            }
            return entity;

        }
    }
}
