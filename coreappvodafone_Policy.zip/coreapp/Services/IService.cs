﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace coreapp.Services
{
    /// <summary>
    /// The Repository Interface will be typed to
    /// 1. TEntity the entity class for CRUD Operations with Table
    /// 2. TPk, the input parameter to methods 
    /// performing Update and Delete
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    /// <typeparam name="TPk"></typeparam>
    public interface IService<TEntity, in TPk> where TEntity: class 
    {
        Task<IEnumerable<TEntity>> GetAsync();
        Task<TEntity> GetAsync(TPk id);
        Task<TEntity> Create(TEntity entity);
        Task<TEntity> Update(TPk id, TEntity entity);
        Task<bool> Delete(TPk id);
    }
}
