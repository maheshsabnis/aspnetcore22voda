﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using coreapp.Models;
using Microsoft.EntityFrameworkCore;

namespace coreapp.Services
{
    public class SubscriberService : IService<Subscriber, int>
    {
        AppDbVodafoneContext ctx; 
        public SubscriberService(AppDbVodafoneContext ctx)
        {
            this.ctx = ctx;
        }

        public  async Task<Subscriber> Create(Subscriber entity)
        {
            var res = await ctx.Subscribers.AddAsync(entity);
            await ctx.SaveChangesAsync();
            return res.Entity;
        }

        public  async Task<bool> Delete(int id)
        {
            var res = await ctx.Subscribers.FindAsync(id);
            if (res != null)
            {
                ctx.Subscribers.Remove(res);
                await ctx.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<IEnumerable<Subscriber>> GetAsync()
        {
            return await ctx.Subscribers.ToListAsync();
        }

        public async Task<Subscriber> GetAsync(int id)
        {
            return await ctx.Subscribers.FindAsync(id);
        }

        public async Task<Subscriber> Update(int id, Subscriber entity)
        {
            var res = await ctx.Subscribers.FindAsync(id);
            if (res != null)
            {
                //ctx.Update<Customers>(entity).State 
                //    = EntityState.Modified;
                res.SubscriberId = entity.SubscriberId;
                res.PlanName = entity.PlanName;
                res.PlanType = entity.PlanType;
                res.MobileNumber = entity.MobileNumber;
                res.CustomerRowId = entity.CustomerRowId;
                await ctx.SaveChangesAsync();
            }
            return entity;

        }
    }
}
