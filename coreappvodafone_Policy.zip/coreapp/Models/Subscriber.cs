﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace coreapp.Models
{
    public class Subscriber
    {
        [Key]
        public int SubscriberRowId { get; set; }
        [Required(ErrorMessage ="Subscriber Id is Must")]
        public string SubscriberId { get; set; }
        [Required(ErrorMessage = "Plan Name  is Must")]
        public string PlanName { get; set; }
        [Required(ErrorMessage = "Plan Type  is Must")]
        public string PlanType { get; set; }
        [Required(ErrorMessage = "Mobile number is Must")]
        public string MobileNumber { get; set; }
        [Required(ErrorMessage = "Customer Row Id is Must")]
        public int CustomerRowId { get; set; }
        public Customers Customer { get; set; }
    }
}
