﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace coreapp.Models
{
    public class Customers
    {
        [Key]
        public int CustomerRowId { get; set; }
        [Required(ErrorMessage ="Customer Id is required")]
        public string CustomerId { get; set; }
        [Required(ErrorMessage = "Customer Name is required")]
        public string CustomerName { get; set; }
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage ="Must be Valida Email")]
        public string EmailAddress { get; set; }
        [Required(ErrorMessage = "Address is required")]
        public string Address { get; set; }
        [Required(ErrorMessage = "City is required")]
       // [CityLength(ErrorMessage ="Length must be less than 10 characters")]
        public string City { get; set; }
        [Required(ErrorMessage = "State is required")]
        public string State { get; set; }
        public ICollection<Subscriber> Subscribers { get; set; }
    }
}
