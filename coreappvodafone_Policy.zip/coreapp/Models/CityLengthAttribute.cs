﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace coreapp.Models
{
    public class CityLengthAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            var val = Convert.ToString(value);
            if (val.Length >= 10)
            {
                return false;
            }
            return true;
        }
    }
}
