﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace coreapp.CustomFilters
{
    public class LogFilterAttribute : ActionFilterAttribute
    {
        void LogRequest(string curState, RouteData route)
        {
            string logMessage = $"Current State is {curState} in " +
                $" Controller {route.Values["controller"]} in" +
                $" Action {route.Values["action"]}";

            Debug.WriteLine(logMessage);
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            LogRequest("OnActionExecuting", context.RouteData);
        }
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            LogRequest("OnActionExecuted", context.RouteData);
        }
        public override void OnResultExecuting(ResultExecutingContext context)
        {
            LogRequest("OnResultExecuting", context.RouteData);
        }
        public override void OnResultExecuted(ResultExecutedContext context)
        {
            LogRequest("OnResultExecuted", context.RouteData);
        }
    }
}
