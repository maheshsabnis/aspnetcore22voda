﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace coreapp.CustomFilters
{
    public class ExceptionFilterAttribute : IExceptionFilter
    {
        IModelMetadataProvider modelMetadata;
        public ExceptionFilterAttribute(IModelMetadataProvider modelMetadata)
        {
            this.modelMetadata = modelMetadata;
        }

        public void OnException(ExceptionContext context)
        {
            // 1. Handle The exception
            // This will inform the HttpContext that
            // the Current Request is about to complete
            context.ExceptionHandled = true;

            // 2. Read the Error Message
            var message = context.Exception.Message;

            // 3. Return the ViewResult

            // arraneg the data to be send to the Error View
            
            var viewResult = new ViewResult()
            {
                ViewName = "CustomErrorView",
            };
           
            // var dictionary = new ViewDataDictionary(modelMetadata, context.ModelState);

          viewResult.ViewData = new ViewDataDictionary(modelMetadata, context.ModelState); ;

            viewResult.ViewData["ControllerName"] = context.RouteData.Values["controller"];
            viewResult.ViewData["ActionName"] = context.RouteData.Values["action"];
            viewResult.ViewData["ErrorMessage"] = message;

            context.Result = viewResult;


        }
    }
}
