﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace coreapp.Models
{
    public class AppDbVodafoneContext : DbContext
    {
        public DbSet<Customers> Customers { get; set; }
        public DbSet<Subscriber> Subscribers { get; set; }
        /// <summary>
        /// The ctor will read the connectionstring from the 
        /// DI Container
        /// </summary>
        /// <param name="options"></param>
        public AppDbVodafoneContext
            (DbContextOptions<AppDbVodafoneContext> options)
            : base(options)
        {

        }

        /// <summary>
        /// Method will be used to create Tables based on Models 
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating
            (ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
