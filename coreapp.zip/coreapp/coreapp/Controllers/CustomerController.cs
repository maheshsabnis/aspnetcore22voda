﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using coreapp.Models;
using coreapp.Services;
namespace coreapp.Controllers
{
    public class CustomerController : Controller
    {
        IService<Customers, int> custService;
        public CustomerController(IService<Customers, int> custService)
        {
            this.custService = custService;
        }
        public IActionResult Index()
        {
            var customers = custService.GetAsync().Result;
            return View(customers);
        }

        public IActionResult Create()
        {
            var customer = new Customers();
            return View(customer);
        }

        [HttpPost]
        public IActionResult Create(Customers customer)
        {
            if (ModelState.IsValid)
            {
                customer  = custService.Create(customer).Result;
                return RedirectToAction("Index");
            }
            return View(customer);
        }

        public IActionResult Edit(int id)
        {
            var customer = custService.GetAsync(id).Result;
            return View(customer);
        }

        [HttpPost]
        public IActionResult Edit(int id, Customers customer)
        {
            if (ModelState.IsValid)
            {
                customer = custService.Update(id,customer).Result;
                return RedirectToAction("Index");
            }
            return View(customer);
        }

        public IActionResult Delete(int id)
        {
            var res = custService.Delete(id).Result;
            if (res)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
    }
}